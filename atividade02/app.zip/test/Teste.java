/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javaapplication6.SenhaValidator;
import javaapplication6.Usuario;
import javaapplication6.UsuarioDAO;
import javaapplication6.UsuarioValidator;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Rule;
import org.junit.rules.ExpectedException;


/**
 *
 * @author Henrique
 */
public class Teste {
    
    private static Usuario u;
    private static UsuarioDAO usuarioDao;
    private static UsuarioValidator uv;
    
   
    
    public Teste() {
        
    }
    
   @Test
   public void testNomePequeno() throws Exception{
        u = new Usuario();
        u.setNome("Hen");
        u.setSenha("12345");
        u.setSenhaConfirmada("12345");
       
        uv.ehUsuarioValido(u);
        
       assertEquals(this, uv.ehUsuarioValido(u));
   }
    
    @Test
   public void testSenhasDiferentes() throws Exception{
        u = new Usuario();
        u.setNome("Henrique");
        u.setSenha("12345");
        u.setSenhaConfirmada("123456");
       
       assertEquals(this, uv.ehUsuarioValido(u));
   }
   
   @Test
   public void testSenhasInválidas() throws Exception{
       u = new Usuario();
        u.setNome("Henrique");
        u.setSenha("1");
        u.setSenhaConfirmada("1");
       
       assertEquals(this, uv.ehUsuarioValido(u));
   }
   
}
